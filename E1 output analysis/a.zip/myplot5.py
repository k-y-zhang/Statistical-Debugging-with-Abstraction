#!python3
# %%
import pandas as  pd 
df1 = pd.read_csv('exp1_1.csv')
df2 = pd.read_csv('exp1_2.csv')

df3 = pd.concat([df1,df2])
df3
# %%
import matplotlib.ticker
from matplotlib.ticker import FuncFormatter
import re
import os
import glob
from matplotlib import pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

def plt_savefig(name):
    plt.grid(False)
    plt.savefig(f"results3/{name}.pdf")
    plt.savefig(f"results3/{name}.png")
    pass


os.makedirs("results3", exist_ok=True)
# %%
def dfff(g, vals,dy=0.05):
    
    for v, e in zip(vals, sorted(g.patches, key=lambda x: x.xy)):
        plt.text(e.xy[0]+0.05, e.get_height()+dy, v, rotation=+90)
def sett():
    #return
    plt.xlabel('subject')
    plt.gca().yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(xmax=100,decimals=2))

# %%
DF1=df3
# %%
# 1  插桩数。
DF1['inst_num'] = (DF1['coarse-grained.profile.number']+DF1['boost.profile.number'] +
                   DF1['prune-minus-boost.profile.number'])

DF1['inst'] = (DF1['coarse-grained.profile.number']+DF1['boost.profile.number'] +
               DF1['prune-minus-boost.profile.number'])/DF1['fine-grained.profile.number']


plt.style.use('ggplot')  

g = sns.barplot(data=DF1, x='pid',
                hue='top-k', y='inst', ci=None, edgecolor='black', linewidth=2)




vals = DF1.groupby(['pid', 'top-k'])['inst_num'].mean()
dfff(g, map(int, vals))
plt.xlabel('subject')
plt.ylabel('')
# plt.axes((None,None,None,None))
plt.ylim(0, 1)


sett()
plt_savefig("inst_percent")
 
# %%









# 2 测试信息收集时间+空间
DF1['percent2_1_0'] = (DF1['coarse-grained.profile.time']+DF1['boost.profile.time'] +
                       DF1['prune-minus-boost.profile.time'])

DF1['percent2_1'] = (DF1['coarse-grained.profile.time']+DF1['boost.profile.time'] +
                     DF1['prune-minus-boost.profile.time'])/DF1['fine-grained.profile.time']
DF1['percent2_2_0'] = (DF1['coarse-grained.profile.size']+DF1['boost.profile.size'] +
                       DF1['prune-minus-boost.profile.size'])

DF1['percent2_2'] = (DF1['coarse-grained.profile.size']+DF1['boost.profile.size'] +
                     DF1['prune-minus-boost.profile.size'])/DF1['fine-grained.profile.size']
g = sns.barplot(data=DF1, x='pid',
                hue='top-k', y='percent2_1', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
dfff(g, map(lambda x:f"{x:0.0f}ms", DF1.groupby(['pid','bid', 'top-k'])['percent2_1_0'].mean()),dy=0.15)
sett()
plt.ylim(0,3)
plt_savefig("test_time")
plt.figure()
g = sns.barplot(data=DF1, x='pid',
                hue='top-k', y='percent2_2', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
dfff(g, map(lambda x:f"{x:0.0f}B", DF1.groupby(['pid', 'top-k'])['percent2_2_0'].mean()))
sett()
plt.ylim(0,1.5)
plt_savefig("test_size")

# #%%
# DF2=DF1[DF1['pid']=='Closure']
# for i in range(10):
#     sns.catplot(kind='bar', data=DF2[DF2['bid']//10==i], col='pid', x='bid',                hue='top-k', y='percent2_1', ci=None, edgecolor='black', linewidth=2)
# %%










# 3 preprocess 时间+空间

# %%
cs=[]
for c in DF1.columns:
    c=str(c)
    #print(str(c))
    if any(map(lambda x:c.startswith(x),["fine-grained.",'boost.','coarse-grained.'])):
        cs.append(c)
        print(c)
DF1.loc[DF1['top-k']==5,cs]=DF1.loc[DF1['top-k']==1,cs].to_numpy()
DF1.loc[DF1['top-k']==10,cs]=DF1.loc[DF1['top-k']==1,cs].to_numpy()
#DF1.loc[DF1['top-k']==5,cs]
# %%
# %%    
DF1['percent3_1_0'] = (DF1['boost.preprocess.time_p'] +
                     DF1['prune.preprocess.time_p'])
DF1['percent3_1'] = (DF1['boost.preprocess.time_p'] +
                     DF1['prune.preprocess.time_p'])/DF1['fine-grained.preprocess.time_p']
DF1['percent3_2_0'] = np.max([DF1['boost.preprocess.size'],
                           DF1['prune.preprocess.size']], axis=0)
DF1['percent3_2'] = np.max([DF1['boost.preprocess.size'],
                           DF1['prune.preprocess.size']], axis=0)/DF1['fine-grained.preprocess.size']

plt.figure()
g = sns.barplot(
    data=DF1, x='pid', hue='top-k', y='percent3_1', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
plt.ylim(0,1.5)

dfff(g, map(lambda x:f"{x:0.0f}ms", DF1.groupby(['pid', 'top-k'])['percent3_1_0'].mean()),0.06)
sett()
plt_savefig("preprocess_time")
plt.figure()
g = sns.barplot(data=DF1, x='pid',
            hue='top-k', y='percent3_2', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
plt.ylim(0,1.5)
dfff(g, map(lambda x:f"{x:0.0f}B", DF1.groupby(['pid', 'top-k'])['percent3_2_0'].mean()))

sett()
plt_savefig("preprocess_size")
#DF1.loc[DF1['pid'] == 'Lang', ['bid', 'top-k', 'percent3_2']]
# %%
def debug1():
    for k,v in DF1.iterrows():
        #print(v)
        pass
    ddd = DF1[['pid','bid','top-k','prune.preprocess.time_p']].pivot(index=['pid','bid'],columns='top-k',values='prune.preprocess.time_p')
    print(ddd)
    print(ddd[(ddd[5]>ddd[10])].to_csv("x.csv"))


debug1()
# %%
# DF2 = DF1[DF1['pid'] == 'Mockito']
# for i in range(1, 50):

#     print(i, DF2[DF2['bid'] == i])
#     if(len(DF2[DF2['bid'] == i])==0):
#         continue
#     sns.catplot(kind='bar', data=DF2[DF2['bid'] == i], x='pid',
#                 hue='top-k', y='percent3_2', ci=None, edgecolor='black', linewidth=2)
#     plt.title(f"{i}")
# %%










# 4 mine 时间+空间
# DF1.loc[DF1['top-k'] == 5, 'fine-grained.mine.time'] = np.array(
#     DF1.loc[DF1['top-k'] == 1, 'fine-grained.mine.time'])
# DF1.loc[DF1['top-k'] == 10, 'fine-grained.mine.time'] = np.array(
#     DF1.loc[DF1['top-k'] == 1, 'fine-grained.mine.time'])
DF1['percent4_1_0'] = (DF1['boost.mine.time'] +
                     DF1['prune.mine.time'])
DF1['percent4_1'] = (DF1['boost.mine.time'] +
                     DF1['prune.mine.time'])/DF1['fine-grained.mine.time']
DF1['percent4_2_0'] = np.max([DF1['boost.mine.size'],
                           DF1['prune.mine.size']], axis=0)
DF1['percent4_2'] = np.max([DF1['boost.mine.size'],
                           DF1['prune.mine.size']], axis=0)/DF1['fine-grained.mine.size']
plt.figure()
g = sns.barplot(data=DF1, x='pid',
            hue='top-k', y='percent4_1', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
plt.ylim(0,10)
dfff(g, map(lambda x:f"{x:0.0f}ms", DF1.groupby(['pid', 'top-k'])['percent4_1_0'].mean()),0.4)

sett()
plt_savefig("mine_time")
plt.figure()
g = sns.barplot(data=DF1, x='pid',
            hue='top-k', y='percent4_2', ci=None, edgecolor='black', linewidth=2)
plt.xlabel('subject')
plt.ylabel('')
plt.ylim(0,2)

dfff(g, map(lambda x:f"{x:0.0f}B", DF1.groupby(['pid', 'top-k'])['percent4_2_0'].mean()),0.1)

sett()
plt_savefig("mine_size")

# %%


def fff():
    df = DF1.loc[DF1['pid'] == 'Lang', ['bid', 'top-k', 'percent4_1', ]]
    for i in range(3):
        print(i)
        # print(df.loc[(df['bid']//10)==i,:])
        plt.figure('')
        sns.barplot(data=df[(df['bid']//10) == i],
                    hue='top-k', x='bid', y='percent4_1')
        plt.show()
    #    break
# %%
DF1
# %%
