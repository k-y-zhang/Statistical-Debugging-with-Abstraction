./mbs -n 0.5 -k 2 --up-limit 2 --refine 2 --merge --dfs mps-ds.pb
